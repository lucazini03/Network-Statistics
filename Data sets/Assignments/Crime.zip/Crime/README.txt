
Data description
-------------------------------------------------
This data concerns the moreno_crime network: This bipartite network contains persons who appeared in at least one crime case as either a suspect, a victim, a witness or both a suspect and victim at the same time. A left node represents a person and a right node represents a crime. An edge between two nodes shows that the left node was involved in the crime represented by the right node. 

More information about the network is provided here: 
http://konect.cc/networks/moreno_crime

Files:
-------------------------------------------------
ent.name		Names of the persons associated to nodes
graph			Edges between the nodes
person.role		The role of each node