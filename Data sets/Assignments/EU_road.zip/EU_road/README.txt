Data description
-------------------------------------------------
This data concerns the Euro Road network: This is the international E-road network, a road network located mostly in Europe.  The network is undirected; nodes represent cities and an edge between two nodes denotes that they are connected by an E-road. 

More information about the network is provided here: 
http://konect.cc/networks/subelj_euroroad
https://wwwlovre.appspot.com/publications.jsp?show=bpa#bpa

Files:
-------------------------------------------------
city.name		Names of the cities associated to nodes
graph			Edges between the nodes
